## 1. Importe la librería tidyverse y la base de datos siu_procesada.csv

## 2. ¿Cuál es la disciplina de estudios que tiene mayor numero de egresades? 

## 3. ¿Cuál es la carrera con mayor porcentaje de mujeres inscriptas? ¿Y la carrera con mayor porcentaje de varones? 

## 4. Plasme en un gráfico la composición desagregada por género de todas las carreras. 

## 5. ¿Cuál es el top 3 de disciplinas estudiadas en universidades de gestión pública? ¿Y cuál es el 
## top 3 de disciplinas estudiadas en universidades de gestión privada?

